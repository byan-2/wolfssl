Files in IDE\Espressif\ESP-IDF\libs:

`CMakeLists.txt` used in ESP-IDF `wolfssl` component directory

`component.mk` used in ESP-IDF `wolfssl` component directory

`tigard.cfg` Tigard JTAG config file 