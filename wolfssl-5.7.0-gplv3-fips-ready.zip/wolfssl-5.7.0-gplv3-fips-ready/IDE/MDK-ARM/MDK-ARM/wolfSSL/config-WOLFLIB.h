
#define SINGLE_THREADED  /* or define RTOS option */

#define WOLFSSL_USER_IO  /* Use own TCP/IP lib */

#define NO_DEV_RANDOM
#define WOLFSSL_MDK_ARM

#define NO_WOLFSSL_DIR
#define NO_WRITEV

#define USE_FAST_MATH
#define TFM_TIMING_RESISTANT
